# Version 2.0.0-pre-alpha
- Angular 2, Angular-cli and structuring of the app
<?php namespace App\Models\Auth;

use Illuminate\Database\Eloquent\Model;

class Login extends Model
{

     protected $fillable = ['username', 'password'];

}
?>
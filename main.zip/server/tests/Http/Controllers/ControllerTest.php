<?php

use Laravel\Lumen\Testing\DatabaseTransactions;
use App\Http\Controllers;

class ControllerTest extends TestCase
{
    /**
     * A basic test index.
     *
     * @return void
     */
    public function testControllerIndex()
    {
        $this->assertTrue(true);
    }
}
